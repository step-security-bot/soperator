## 0.12.0 (Unreleased)

## 0.11.0 (April 9, 2024)

FEATURES:
* provider: allow to change `interconnect_physical_cluster` parameter at `nebius_compute_gpu_cluster` resource

## 0.10.0 (March 20, 2024)

FEATURES:
* **New Data Source:** `nebius_mdb_opensearch_cluster`
* **New Resource:** `nebius_mdb_opensearch_cluster`

## 0.9.0 (February 29, 2024)

FEATURES:
* provider: add `interconnect_physical_cluster` parameter to `nebius_compute_gpu_cluster` resource

## 0.8.0 (December 21, 2023)

FEATURES:
* provider: allow creating `public` dns zones along with `private` and `public-private` once
* provider: allow updating dns zone visibility (all transitions are allowed except `public-private -> public` one)

BUG FIXES:
* clickhouse: updating only the changed user settings
* storage: fix bug not allowing to remove grants and acl by removing `grant` and `acl` fields

## 0.7.0 (October 31, 2023)

FEATURES:
* postgresql: add postgresql 16 support

ENHANCEMENTS:
* managed-kubernetes: support update of `allocation_policy.locations` section for `nebius_kubernetes_node_group`

## 0.5.0 (October 25, 2023)

FEATURES:
* managed-kubernetes: add `master_location`, `etcd_cluster_size` in `nebius_kubernetes_cluster` resource and data source

## 0.4.0 (October 24, 2023)

ENHANCEMENTS:
* mdb: add `disk_size_autoscaling` attribute to `config` entity in `nebius_mdb_postgresql_cluster` resource and data source
* datasphere: add documentation for datasphere resources and data sources

FEATURES:
* compute: added support for `instance_tags_pool` in `nebius_compute_instance_group`
* compute: added support for `ignore_health_checks` in `nebius_compute_instance_group`

BUG FIXES:
* compute: fix `filesystem` in `compute_instance_group` resource
* postgresql: do not recreate cluster on network change
