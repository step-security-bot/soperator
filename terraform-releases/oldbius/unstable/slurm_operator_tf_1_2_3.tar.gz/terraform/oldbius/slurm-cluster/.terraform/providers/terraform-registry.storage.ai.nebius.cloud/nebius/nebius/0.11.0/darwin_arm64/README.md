# Terraform Provider `nebius`

Documentation: https://terraform-provider.website.ai.nebius.cloud

## Development

### Run

1. Create `main.tf`:
   ```hcl
   terraform {
     required_providers {
       nebius = {
         source = "nebius/nebius"
       }
     }
   }
   
   provider "nebius" {
     zone = "eu-north1-c"
   }
   
   data "nebius_resourcemanager_folder" "folder" {
     folder_id = "yc.public-api.private-registry"
   }
   
   output "folder" {
     value = data.nebius_resourcemanager_folder.folder
   }
   ```
1. Create `dev.tfrc`:
   ```hcl
   provider_installation {
     dev_overrides {
       "nebius/nebius" = "bin"
     }
     direct {}
   }
   ```
1. Build plugin binary:
   ```shell
   go build -o bin/
   ```
1. Run `terraform apply`:
   ```shell
   NCP_TOKEN="$(ncp iam create-token)" TF_CLI_CONFIG_FILE="dev.tfrc" terraform apply
   ```

### Debug

1. Prepare `main.tf` like above.
1. Run `main.go` in your favourite debugger with flag `-debug`.
   Do not forget to define token either via env `NCP_TOKEN` or in `main.tf`.
1. Wait for the following in stdout:
   ```
   Provider started. To attach Terraform CLI, set the TF_REATTACH_PROVIDERS environment variable with the following:

        TF_REATTACH_PROVIDERS='{"nebius/nebius":{"Protocol":"grpc","ProtocolVersion":6,"Pid":...}}'
   ```
1. Put breakpoints.
1. Run `terraform` with env `TF_REATTACH_PROVIDERS` from the output:
   ```shell
   TF_REATTACH_PROVIDERS='{"nebius/nebius":...}' terraform apply
   ```
1. You can repeat the previous point without restarting of `main.go`.
